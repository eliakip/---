<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=100&pause=1000&color=FF0000&center=true&width=1000&height=200&lines=Eliakim-Xmd" alt="Typing SVG" /></a>
  </p>
  
---   

> **`Updated To` The Version 1.0**

---

<a><img src='https://files.catbox.moe/4i1zqg.jpg'/></a>

<div align="center">
  
[![WhatsApp Channel](https://img.shields.io/badge/Join-WhatsApp%20Channel-FF00F8?style=big-square&logo=whatsapp)](https://whatsapp.com/channel/0029VbAF7Og65yD6dbZeBv2t)
</div>



### 1. Fork This Repository

Start by forking this repository to your own GitHub account. Click the button below to fork:

  <a href="https://github.com/eliakip/Eliakim-Xmd/fork"><img title="𝖊𝖑𝖎𝖆𝖐𝖎𝖒 𝖝𝖒𝖉" src="https://img.shields.io/badge/FORK-𝖊𝖑𝖎𝖆𝖐𝖎𝖒-𝖝𝖒𝖉h?color=green&style=for-the-badge&logo=stackshare"></a>

> Get Pair Code (Session ID)



<p align="left">  
<a href='https://khanmdx.onrender.com' target="_blank"><img alt='Get Pairing Code' src='https://img.shields.io/badge/Get%20Pairing%20Code-B700FB?style=for-the-badge&logo=codefactor&logoColor=white'/></a>  
</p>

🚀 ##Deploy

> Deploy on Heroku



<p align="left">  
<a href='https://dashboard.heroku.com/new?template=https://github.com/eliakip/Eliakim-Xmd' target="_blank"><img alt='Deploy on Heroku' src='https://img.shields.io/badge/Deploy%20on-Heroku-FF004D?style=for-the-badge&logo=heroku&logoColor=white'/></a>  
</p>



🏆 Credits & Contributors
> Owner 
- [𝖊𝖑𝖎𝖆𝖐𝖎𝖒](https://github.com/eliakip)

> Dev
- [Marisel](https://github.com/betingrich3)
- For helping in bot plugin files.
  



🔒 Final Note

If you face any issues, report them on GitHub or in the WhatsApp community.
Happy coding! 🚀 
